import csv
import io
import tempfile
import unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from core import connect,create_job,save_page,normalize_user,guess_country,import_csv,followers_as_dicts
from exporter import make_excel

class TestMirsad(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.db=connect(Path(self.tmp.name)/'db.sqlite3')
        self.job=create_job(self.db,'X','demo','99999')
    def tearDown(self):
        self.db.close();self.tmp.cleanup()
    def test_text_id_and_duplicates(self):
        rows=[{'id':'1234567890123456789','username':'a','location':'Riyadh'}, {'id':'1234567890123456789','username':'a','location':'Riyadh'}]
        added,dups=save_page(self.db,self.job,rows,'NEXT',0.4)
        self.assertEqual((added,dups),(1,1))
        self.assertEqual(followers_as_dicts(self.db,self.job)[0]['uid'],'1234567890123456789')
    def test_country_is_heuristic(self):
        self.assertEqual(guess_country('الرياض'),'السعودية')
        self.assertEqual(guess_country('Mars'),'غير محددة')
    def test_csv_and_workbook(self):
        data='id,username,name,location\n1234567890123456789,user1,Name,Riyadh\n1234567890123456790,user2,Name,Doha\n'
        self.assertEqual(import_csv(self.db,self.job,data.encode()),2)
        job=dict(self.db.execute('SELECT * FROM jobs WHERE id=?',(self.job,)).fetchone())
        result=make_excel(followers_as_dicts(self.db,self.job),[],job)
        self.assertGreater(len(result),3000)
        self.assertEqual(result[:2],b'PK')
    def test_no_invalid_id(self):
        self.assertIsNone(normalize_user({'id':'1.2345E+18'}))

if __name__=='__main__':unittest.main()
